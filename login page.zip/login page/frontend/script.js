// Dynamic Event Name
window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const eventName = urlParams.get('event');
    document.getElementById('event-name').innerText = eventName || "Unknown Event";
}

// Form submission logic
document.getElementById('registration-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append('event', document.getElementById('event-name').innerText);

    fetch('http://localhost:3000/register', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        // Optionally, reset form after submission
        document.getElementById('registration-form').reset();
    })
    .catch(error => {
        alert('Error: ' + error.message);
    });
});
